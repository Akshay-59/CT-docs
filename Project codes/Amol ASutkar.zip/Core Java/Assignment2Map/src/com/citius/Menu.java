package com.citius;

import java.util.Scanner;

public class Menu {

	static CountryInfo cinfo=new CountryInfo();
	public static void main(String[] args) {
		
		Scanner sc= new Scanner(System.in);
		int choice;

		System.out.println("------------Menu------------ ");
		System.out.println("\n1. Country By Capital \n2. Capital By Country \n0. Exit");
		
         
         do {
        	 System.out.println("enter your choice");
     		
             choice = sc.nextInt();
        	 
        	 switch (choice) {
        	 
        	 case 1: cinfo.countryByCapital();
        	         break;
        	 case 2: cinfo.capitalByCountry();;
	                 break;
	         default: 
	        	 if(choice==0) {
	        		 System.out.println("thanks for exit");
	        	 }
	        	 else {
	        		 System.out.println("please enter valid choice");
	        	 }
        	 }
        	 
         }while(choice != 0);
		
	}
}

package com.citius;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class CountryInfo {
	Scanner sc= new Scanner(System.in);

	public  CountryInfo() {
	
	Map<String, String> countrymap=new HashMap<String, String>();
	countrymap.put("India","Delhi");
	countrymap.put("Japan","Tokyo");
	}
	
	public void countryByCapital() {
		Map<String, String> countrymap=new HashMap<String, String>();
		countrymap.put("India","Delhi");
		countrymap.put("Japan","Tokyo");
		System.out.println("enter country : ");
		String country=sc.next();
		for(Map.Entry<String, String> entry:countrymap.entrySet()) {
			if(entry.getKey().equals(country)) {
				//System.out.println("key=="+entry.getKey() +""+"Value="+entry.getValue());
				System.out.println("the City is  :"+entry.getValue());
			}
			
		}
		
	}
	
	public  void capitalByCountry() {
		
		
		Map<String, String> countrymap=new HashMap<String, String>();
		countrymap.put("India","Delhi");
		countrymap.put("Japan","Tokyo");
		System.out.println("enter city : ");
		String city=sc.next();
		for(Map.Entry<String, String> entry:countrymap.entrySet()) {
			if(entry.getValue().equals(city)) {
				//System.out.println("key=="+entry.getKey() +""+"Value="+entry.getValue());
				System.out.println("the Country is  :"+entry.getKey());
			}
			
		}
			
	}

}

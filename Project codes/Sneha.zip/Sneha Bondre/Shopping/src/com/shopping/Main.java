package com.shopping;

public class Main {

	public static void main(String[] args) {
		Customer customer = new Customer();
		boolean isLogged = customer.Login();
		if(isLogged==true) {
		Common common = new Common();

		}
	}
}
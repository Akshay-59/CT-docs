package com.citiustech;

import com.citiustech.service.Menu;

public class MainClass {
	
	public static void main(String[] args) throws ClassNotFoundException {
		Menu menu = new Menu();
	}
} 

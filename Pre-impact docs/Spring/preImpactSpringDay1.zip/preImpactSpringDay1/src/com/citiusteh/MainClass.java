package com.citiusteh;

public class MainClass {

	public static void main(String[] args) {
		//object creation is done by us
		Message obj = new Message();
		obj.setMessage("Good Afternoon");
		System.out.println("Hello All "+obj.getMessage());

	}

}

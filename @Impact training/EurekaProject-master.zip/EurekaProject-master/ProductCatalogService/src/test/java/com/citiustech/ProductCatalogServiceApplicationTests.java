package com.citiustech;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductCatalogServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}

using System;

public class EmpClass
{
	public EmpClass()
    {
		
	}	
	
	
	public string GetData()
	{
		
		return "Hello World";
	}
}
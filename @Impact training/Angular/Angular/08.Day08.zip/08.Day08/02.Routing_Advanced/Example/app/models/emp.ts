export class Emp {
}
